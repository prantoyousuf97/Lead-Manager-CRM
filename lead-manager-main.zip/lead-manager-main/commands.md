npm init
npm init -y
npm install -D nodemon
npm start
npm install express
npm install mongoose
npm install uuid
npm install crypto
npm install nodemailer
npm install bcrypt
npm install jsonwebtoken 
npm install cors 
npm install cookie-parser
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"